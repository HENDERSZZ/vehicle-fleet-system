-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql301.infinityfree.com
-- Generation Time: Oct 11, 2026 at 04:33 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43119735_myapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `user_id`, `action`, `created_at`) VALUES
(1, 4, 'User login', '2026-10-08 02:34:21'),
(2, 4, 'User logout', '2026-10-08 02:51:10'),
(3, 4, 'User login', '2026-10-08 02:52:43'),
(4, 4, 'User logout', '2026-10-08 03:30:10'),
(5, 95, 'User login', '2026-10-08 03:30:21'),
(6, 95, 'User login', '2026-10-08 03:37:59'),
(7, 95, 'User logout', '2026-10-08 03:51:18'),
(8, 95, 'User login', '2026-10-08 03:51:22'),
(9, 95, 'User logout', '2026-10-08 03:51:37'),
(10, 4, 'User login', '2026-10-08 03:51:42'),
(11, 4, 'User logout', '2026-10-08 04:10:08'),
(12, 4, 'User login', '2026-10-08 04:10:10'),
(13, 4, 'User logout', '2026-10-08 05:39:03'),
(14, 95, 'User login', '2026-10-08 05:39:07'),
(15, 95, 'User logout', '2026-10-08 05:46:41'),
(16, 4, 'User login', '2026-10-08 05:46:44'),
(17, 4, 'User login', '2026-10-08 05:47:49'),
(18, 4, 'User login', '2026-10-08 05:48:05'),
(19, 4, 'User login', '2026-10-08 05:49:16'),
(20, 4, 'User logout', '2026-10-08 06:11:15'),
(21, 95, 'User login', '2026-10-08 06:11:19'),
(22, 95, 'User logout', '2026-10-08 06:11:34'),
(23, 4, 'User login', '2026-10-08 06:11:39'),
(24, 4, 'User logout', '2026-10-08 06:19:11'),
(25, 95, 'User login', '2026-10-08 06:19:15'),
(26, 95, 'User logout', '2026-10-08 06:19:44'),
(27, 4, 'User login', '2026-10-08 06:19:47'),
(28, 4, 'User login', '2026-10-08 06:21:25'),
(29, 4, 'User logout', '2026-10-08 07:13:32'),
(30, 95, 'User login', '2026-10-08 07:13:37'),
(31, 95, 'User logout', '2026-10-08 07:13:57'),
(32, 4, 'User login', '2026-10-08 07:14:01'),
(33, 4, 'User logout', '2026-10-08 07:15:06'),
(34, 4, 'User login', '2026-10-08 07:15:08'),
(35, 4, 'User logout', '2026-10-08 07:15:11'),
(36, 95, 'User login', '2026-10-08 07:15:15'),
(37, 95, 'User logout', '2026-10-08 07:16:12'),
(38, 4, 'User login', '2026-10-08 07:16:16'),
(39, 4, 'User login', '2026-10-08 07:18:06'),
(40, 4, 'User logout', '2026-10-08 07:20:17'),
(41, 4, 'User login', '2026-10-08 07:20:20'),
(42, 4, 'User logout', '2026-10-08 07:20:26'),
(43, 96, 'User login', '2026-10-08 07:20:42'),
(44, 96, 'User logout', '2026-10-08 07:21:50'),
(45, 4, 'User login', '2026-10-08 07:21:54'),
(46, 4, 'User logout', '2026-10-08 07:22:53'),
(47, 96, 'User login', '2026-10-08 07:22:58'),
(48, 96, 'User logout', '2026-10-08 07:25:47'),
(49, 4, 'User login', '2026-10-08 07:25:51'),
(50, 4, 'User login', '2026-10-10 04:43:40'),
(51, 4, 'User login', '2026-10-10 04:52:36'),
(52, 4, 'User login', '2026-10-10 04:52:59'),
(53, 4, 'User login', '2026-10-10 04:53:11'),
(54, 4, 'User logout', '2026-10-10 05:36:25'),
(55, 96, 'User login', '2026-10-10 05:36:31'),
(56, 96, 'User logout', '2026-10-10 05:37:44'),
(57, 4, 'User login', '2026-10-10 05:37:48'),
(58, 4, 'User logout', '2026-10-10 05:38:51'),
(59, 96, 'User login', '2026-10-10 05:38:56'),
(60, 96, 'User logout', '2026-10-10 09:05:20'),
(61, 96, 'User login', '2026-10-10 09:05:24'),
(62, 96, 'User logout', '2026-10-10 09:07:16'),
(63, 4, 'User login', '2026-10-10 09:07:20'),
(64, 4, 'User logout', '2026-10-10 09:08:04'),
(65, 96, 'User login', '2026-10-10 09:08:08'),
(66, 96, 'User logout', '2026-10-10 09:09:07'),
(67, 4, 'User login', '2026-10-10 14:21:49'),
(68, 4, 'User login', '2026-10-10 21:31:12'),
(69, 4, 'User login', '2026-10-10 21:31:15'),
(70, 4, 'User login', '2026-10-10 21:31:18'),
(71, 4, 'User login', '2026-10-10 21:31:20'),
(72, 4, 'User login', '2026-10-10 21:31:23'),
(73, 4, 'User login', '2026-10-10 21:31:25'),
(74, 4, 'User login', '2026-10-10 21:31:27'),
(75, 4, 'User login', '2026-10-10 21:31:28'),
(76, 4, 'User login', '2026-10-10 21:31:30'),
(77, 4, 'User login', '2026-10-10 21:31:31'),
(78, 4, 'User login', '2026-10-10 21:35:47'),
(79, 4, 'User login', '2026-10-10 21:35:49'),
(80, 4, 'User login', '2026-10-10 21:35:51'),
(81, 4, 'User login', '2026-10-10 21:35:53'),
(82, 4, 'User login', '2026-10-10 21:35:58'),
(83, 4, 'User login', '2026-10-10 21:46:09'),
(84, 4, 'User logout', '2026-10-10 21:46:23'),
(85, 4, 'User login', '2026-10-10 21:46:25'),
(86, 4, 'User login', '2026-10-11 01:08:03'),
(87, 4, 'User login', '2026-10-11 01:10:12'),
(88, 4, 'User logout', '2026-10-11 01:13:09'),
(89, 4, 'User login', '2026-10-11 01:13:11'),
(90, 4, 'User logout', '2026-10-11 01:13:33'),
(91, 4, 'User logout', '2026-10-11 01:14:12'),
(92, 96, 'User login', '2026-10-11 01:14:16'),
(93, 96, 'User login', '2026-10-11 01:16:16'),
(94, 96, 'User logout', '2026-10-11 01:24:09'),
(95, 4, 'User login', '2026-10-11 01:24:18');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Saloon Car'),
(2, 'SUV'),
(3, 'Pickup'),
(4, 'Motorcycle');

-- --------------------------------------------------------

--
-- Table structure for table `counties`
--

CREATE TABLE `counties` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `counties`
--

INSERT INTO `counties` (`id`, `name`, `region_id`) VALUES
(1, 'Mombasa', 2),
(32, 'Nakuru', 7),
(47, 'Nairobi', 4);

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `region_id` int(11) DEFAULT NULL,
  `county_id` int(11) DEFAULT NULL,
  `subcounty_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `name`, `username`, `password`, `phone`, `status`, `region_id`, `county_id`, `subcounty_id`, `location_id`, `created_at`, `updated_at`) VALUES
(1, 'Ephra Mwas', 'mwas', '$2y$12$tzDj6qItiQ4qZ2evkYkyMeSpFflqmK2f9xmM6SxxWgL/2J407iP5m', '', 'active', 4, 47, 274, 299, '2026-10-08 03:40:07', '2026-10-08 03:40:07');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `subcounty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `subcounty_id`) VALUES
(283, 'Changamwe', 258),
(284, 'Jomvu', 259),
(285, 'Kisauni', 260),
(286, 'Likoni', 261),
(287, 'Mvita', 262),
(288, 'Nyali', 263),
(297, 'Dagoretti North', 272),
(298, 'Dagoretti South', 273),
(299, 'Njiru', 274),
(300, 'Embakasi Central', 275),
(301, 'Embakasi East', 276),
(302, 'Embakasi North', 277),
(303, 'Embakasi South', 278),
(304, 'Embakasi West', 279),
(305, 'Kamukunji', 280),
(306, 'Kasarani', 281),
(307, 'Kibra Sub', 282),
(308, 'Lang\'ata', 283),
(309, 'Makadara', 284),
(310, 'Mathare', 285),
(311, 'Roysambu', 286),
(312, 'Ruaraka', 287),
(313, 'Starehe', 288),
(314, 'Westlands', 289),
(315, 'Bahati', 290),
(316, 'Nakuru North', 291),
(317, 'Gilgil', 292),
(318, 'Kuresoi north', 293),
(319, 'Kuresoi south', 294),
(320, 'Molo', 295),
(321, 'Naivasha', 296),
(322, 'Nakuru town east', 297),
(323, 'Nakuru town west', 298),
(324, 'Njoro', 299),
(325, 'Rongai', 300),
(326, 'Subukia', 301),
(439, 'Nairobi', 288),
(664, 'Nakuru HQ', 297),
(665, 'Kuresoi HQ', 293),
(696, 'Nairobi West', 283),
(702, 'Mugumoini', 283),
(708, 'Kangemi', 289),
(712, 'karura', 289),
(715, 'embakasi', 276),
(722, 'Embakasi', 278),
(727, 'Mukuru kwa njenga', 278),
(736, 'Githurai', 286),
(743, 'Kizingo', 262),
(746, 'Kibra', 282),
(747, 'Embakasi', 275),
(749, 'makadara hq', 284),
(750, 'Bondeni', 297),
(751, 'Maringo', 284),
(752, 'KALOLENI', 284),
(753, 'Hamza', 284),
(765, 'HQ', 297),
(773, 'HQ', 290),
(781, 'HQ', 293),
(805, 'NAKURU WEST HQ', 298),
(806, 'NAKURU WEST', 298),
(807, 'NAKURU WEST', 297),
(1020, 'HQ', 294),
(1051, 'HQ', 299),
(1331, 'HQ', 301),
(1332, 'HQ', 300),
(1451, 'Mombasa', 259),
(1486, 'Mombasa', 261),
(1489, 'Mombasa', 258),
(1513, 'HQ', 295),
(1581, 'Nakuru', 295),
(1584, 'Nakuru', 293),
(1589, 'Nakuru', 296),
(1706, 'Nakuru', 297),
(1762, 'Nakuru', 300),
(1778, 'Nakuru', 292),
(1897, 'HQ', 296),
(1918, 'Nakuru', 291),
(2038, 'Nairobi', 276),
(2040, 'Nairobi', 278),
(2041, 'Nairobi', 277),
(2045, 'Nairobi', 285),
(2047, 'Nairobi', 281),
(2052, 'Nairobi', 280),
(2171, 'Shikaadabu', 261),
(2173, 'Mtongwe', 261),
(2176, 'Vijiweni', 261),
(2181, 'Maweni', 263),
(2194, 'Bomu', 258),
(2204, 'Kombo', 258),
(2209, 'Kwa hola', 258),
(2214, 'Portreitz', 258),
(2217, 'Chaani', 258),
(2777, 'Mombasa', 262);

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `cost` decimal(10,2) NOT NULL,
  `odometer` int(11) DEFAULT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `receipt` varchar(255) DEFAULT NULL,
  `requisition_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `refuel`
--

CREATE TABLE `refuel` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'refuel',
  `regno` varchar(20) NOT NULL,
  `fuel` decimal(10,2) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `odometer` int(11) NOT NULL,
  `station` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `date` datetime DEFAULT current_timestamp(),
  `receipt` varchar(255) DEFAULT NULL,
  `requisition_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`) VALUES
(1, 'Central'),
(2, 'Coast'),
(3, 'Eastern'),
(4, 'Nairobi'),
(5, 'North Eastern'),
(6, 'Nyanza'),
(7, 'Rift Valley'),
(8, 'Western'),
(9, 'Headquarters');

-- --------------------------------------------------------

--
-- Table structure for table `requisitions`
--

CREATE TABLE `requisitions` (
  `id` int(11) NOT NULL,
  `type` enum('fuel','repair','parts','service','inspection','upgrade','general') NOT NULL,
  `vehicle_regno` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `fuel` decimal(10,2) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `station` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requested_at` datetime DEFAULT current_timestamp(),
  `requested_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `requisitions`
--

INSERT INTO `requisitions` (`id`, `type`, `vehicle_regno`, `description`, `amount`, `fuel`, `odometer`, `station`, `status`, `requested_at`, `requested_by`, `approved_by`, `approved_at`) VALUES
(1, 'fuel', 'KDA 101A', 'Travel', '21700.00', '100.00', 120000, 'Shell Karen', 'approved', '2026-10-08 07:21:27', 96, 4, '2026-10-08 07:22:09'),
(2, 'repair', 'KDA 102B', 'rtr', '324.00', NULL, 45434, NULL, 'rejected', '2026-10-10 05:36:01', 4, 96, '2026-10-10 05:36:49'),
(3, 'parts', 'KDA 101A', 'wheel,battery', '120000.00', NULL, 234567, NULL, 'approved', '2026-10-10 05:37:33', 96, 4, '2026-10-10 05:38:03'),
(4, 'repair', 'KDA 102B', 'wheels', '15000.00', NULL, 120000, NULL, 'approved', '2026-10-10 09:07:07', 96, 4, '2026-10-10 09:07:48'),
(5, 'repair', 'KDB 201A', 'shhdh', '3838.00', NULL, 26363, NULL, 'approved', '2026-10-11 01:12:09', 4, 96, '2026-10-11 01:22:37'),
(6, 'parts', 'KDA 102B', 'battery', '8000.00', NULL, 66263, NULL, 'approved', '2026-10-11 01:23:47', 96, 4, '2026-10-11 01:24:27'),
(7, 'fuel', 'KDA 104A', 'dhdh', '10000.00', '20.00', 3273737, 'Rubis Nakuru', 'approved', '2026-10-11 01:25:14', 96, 4, '2026-10-11 01:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `subcounties`
--

CREATE TABLE `subcounties` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `county_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcounties`
--

INSERT INTO `subcounties` (`id`, `name`, `county_id`) VALUES
(258, 'Changamwe', 1),
(259, 'Jomvu', 1),
(260, 'Kisauni', 1),
(261, 'Likoni', 1),
(262, 'Mvita', 1),
(263, 'Nyali', 1),
(272, 'Dagoretti North', 47),
(273, 'Dagoretti South', 47),
(274, 'Njiru', 47),
(275, 'Embakasi Central Sub Count', 47),
(276, 'Embakasi East', 47),
(277, 'Embakasi North', 47),
(278, 'Embakasi South', 47),
(279, 'Embakasi West', 47),
(280, 'Kamukunji', 47),
(281, 'Kasarani', 47),
(282, 'Kibra', 47),
(283, 'Lang\'ata', 47),
(284, 'Makadara', 47),
(285, 'Mathare', 47),
(286, 'Roysambu', 47),
(287, 'Ruaraka', 47),
(288, 'Starehe', 47),
(289, 'Westlands', 47),
(290, 'Bahati', 32),
(291, 'Nakuru North', 32),
(292, 'Gilgil', 32),
(293, 'Kuresoi north', 32),
(294, 'Kuresoi south', 32),
(295, 'Molo', 32),
(296, 'Naivasha', 32),
(297, 'Nakuru town east', 32),
(298, 'Nakuru town west', 32),
(299, 'Njoro', 32),
(300, 'Rongai', 32),
(301, 'Subukia', 32);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_level` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `region_id` int(11) NOT NULL,
  `county_id` int(11) DEFAULT NULL,
  `subcounty_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `image`, `password`, `user_level`, `group_id`, `status`, `region_id`, `county_id`, `subcounty_id`, `location_id`, `last_login`, `last_activity`, `created_at`, `updated_at`) VALUES
(4, 'Andy', 'Andy', '689a362006a6c_girl-8257551_11zon.jpg', '$2y$10$L4tzmRz/29MEWw9Pc2Vd1eoGtC7fay9TbKEZxTeEhtCR7dci4CPo6', 1, 5, 'active', 4, 47, 281, 306, '2026-10-11 11:24:18', '2026-10-11 01:33:37', '2025-07-28 13:25:15', '2026-10-11 01:33:37'),
(95, 'Ander', 'Ander', NULL, '$2y$12$lfFMVfTVeuVEX7Rzhf8Hse74Lg8wSo3DQsQXHIIlinTONxvbp.r12', 2, 2, 'active', 4, 47, 275, 747, '2026-10-08 07:17:51', '2026-10-08 07:33:04', '2026-10-08 03:29:01', '2026-10-08 07:33:04'),
(96, 'Titus', 'Titus', NULL, '$2y$12$6Mx9WmJkhq16TpKvn2QJJ.GbKAFsvWFVhFb654OJloZsDH5eFa3JK', 1, 5, 'active', 9, NULL, NULL, NULL, '2026-10-11 11:16:16', '2026-10-11 01:33:45', '2026-10-08 07:19:57', '2026-10-11 01:33:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Administrator', 1, 'active'),
(2, 'Manager', 2, 'active'),
(5, 'Super Admin', 0, 'active'),
(6, 'Super Manager', 1, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `session_token`, `ip_address`, `user_agent`, `last_activity`, `created_at`) VALUES
(2, 4, 'cc646df709469d00271f6784faec345ea8eaf612f4d61391c8de3d41c23910fe', '102.205.239.225', 'Mozilla/5.0 (X11; Linux x86_64; rv:157.0) Gecko/20100101 Firefox/157.0', '2026-10-11 08:24:18', '2026-10-11 08:24:18');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `chassisno` varchar(100) DEFAULT NULL,
  `engineno` varchar(100) DEFAULT NULL,
  `make` varchar(100) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `subcounty_id` int(11) DEFAULT NULL,
  `county_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `regno`, `chassisno`, `engineno`, `make`, `color`, `designation`, `date`, `category_id`, `status_id`, `location_id`, `subcounty_id`, `county_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'KDA 104A', 'CHS-FK001104', 'ENG-FK001104', 'Toyota', 'White', 'Official Vehicle', '2022-03-15', 1, 1, 297, 272, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(2, 'KDB 215B', 'CHS-FK002215', 'ENG-FK002215', 'Nissan', 'Silver', 'Pool Vehicle', '2021-07-22', 1, 1, 298, 273, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(3, 'KDC 326C', 'CHS-FK003326', 'ENG-FK003326', 'Toyota', 'Black', 'Official Vehicle', '2020-11-10', 2, 1, 299, 274, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(4, 'KDD 437D', 'CHS-FK004437', 'ENG-FK004437', 'Isuzu', 'White', 'Field Vehicle', '2023-01-18', 3, 1, 301, 276, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(5, 'KDE 548E', 'CHS-FK005548', 'ENG-FK005548', 'Mitsubishi', 'Grey', 'Field Vehicle', '2019-06-25', 2, 1, 302, 277, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(6, 'KDF 659F', 'CHS-FK006659', 'ENG-FK006659', 'Toyota', 'Blue', 'Pool Vehicle', '2022-09-14', 2, 1, 303, 278, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(7, 'KDG 760G', 'CHS-FK007760', 'ENG-FK007760', 'Nissan', 'White', 'Official Vehicle', '2021-02-08', 1, 1, 304, 279, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(8, 'KDH 871H', 'CHS-FK008871', 'ENG-FK008871', 'Toyota', 'Silver', 'Field Vehicle', '2020-04-19', 3, 1, 305, 280, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(9, 'KDJ 982J', 'CHS-FK009982', 'ENG-FK009982', 'Subaru', 'Black', 'Official Vehicle', '2023-05-12', 2, 1, 306, 281, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(10, 'KDK 193K', 'CHS-FK010193', 'ENG-FK010193', 'Toyota', 'White', 'Pool Vehicle', '2019-10-30', 1, 1, 307, 282, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(11, 'KDL 204L', 'CHS-FK011204', 'ENG-FK011204', 'Nissan', 'Red', 'Field Vehicle', '2022-12-05', 3, 1, 308, 283, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(12, 'KDM 315M', 'CHS-FK012315', 'ENG-FK012315', 'Toyota', 'Grey', 'Official Vehicle', '2021-08-17', 1, 1, 309, 284, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(13, 'KDN 426N', 'CHS-FK013426', 'ENG-FK013426', 'Isuzu', 'White', 'Field Vehicle', '2020-03-21', 3, 1, 310, 285, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(14, 'KDP 537P', 'CHS-FK014537', 'ENG-FK014537', 'Toyota', 'Silver', 'Pool Vehicle', '2022-06-11', 2, 1, 311, 286, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(15, 'KDQ 648Q', 'CHS-FK015648', 'ENG-FK015648', 'Mitsubishi', 'Black', 'Official Vehicle', '2019-12-09', 2, 1, 312, 287, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(16, 'KDR 759R', 'CHS-FK016759', 'ENG-FK016759', 'Nissan', 'White', 'Field Vehicle', '2023-02-27', 3, 1, 313, 288, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(17, 'KDS 860S', 'CHS-FK017860', 'ENG-FK017860', 'Toyota', 'Blue', 'Official Vehicle', '2021-04-16', 1, 1, 314, 289, 47, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(18, 'KDT 971T', 'CHS-FK018971', 'ENG-FK018971', 'Toyota', 'Grey', 'Pool Vehicle', '2020-09-03', 2, 1, 315, 290, 32, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(19, 'KDU 182U', 'CHS-FK019182', 'ENG-FK019182', 'Nissan', 'White', 'Field Vehicle', '2022-01-24', 3, 1, 316, 291, 32, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(20, 'KDV 293V', 'CHS-FK020293', 'ENG-FK020293', 'Toyota', 'Silver', 'Official Vehicle', '2023-07-07', 1, 1, 288, 263, 1, NULL, NULL, '2026-10-08 05:23:01', '2026-10-08 05:23:01'),
(21, 'KDA 101A', 'DEMO-CH-0001', 'DEMO-EN-0001', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2023-02-14', 2, 1, 283, 258, 1, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(22, 'KDA 102B', 'DEMO-CH-0002', 'DEMO-EN-0002', 'Nissan Hardbody', 'White', 'Pickup', '2022-07-01', 3, 1, 284, 259, 1, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(23, 'KDA 103C', 'DEMO-CH-0003', 'DEMO-EN-0003', 'Toyota Hilux', 'Grey', 'Utility Vehicle', '2021-11-20', 3, 2, 285, 260, 1, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(24, 'KDA 104D', 'DEMO-CH-0004', 'DEMO-EN-0004', 'Honda CRF', 'Red', 'Patrol Bike', '2024-01-05', 4, 1, 283, 258, 1, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(25, 'KDB 201A', 'DEMO-CH-0005', 'DEMO-EN-0005', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2023-05-18', 2, 1, 315, 290, 32, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(26, 'KDB 202B', 'DEMO-CH-0006', 'DEMO-EN-0006', 'Isuzu D-Max', 'Silver', 'Pickup', '2022-09-09', 3, 3, 316, 291, 32, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(27, 'KDB 203C', 'DEMO-CH-0007', 'DEMO-EN-0007', 'Toyota Prado', 'Black', 'Admin Vehicle', '2020-03-30', 2, 2, 317, 292, 32, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(28, 'KDC 301A', 'DEMO-CH-0008', 'DEMO-EN-0008', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2024-04-22', 2, 1, 297, 272, 47, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(29, 'KDC 302B', 'DEMO-CH-0009', 'DEMO-EN-0009', 'Subaru Forester', 'Blue', 'Admin Vehicle', '2021-08-10', 2, 1, 298, 273, 47, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(30, 'KDC 303C', 'DEMO-CH-0010', 'DEMO-EN-0010', 'Honda CRF', 'Red', 'Patrol Bike', '2023-12-01', 4, 4, 299, 274, 47, NULL, NULL, '2026-10-08 05:29:35', '2026-10-08 05:29:35'),
(31, 'KDC123A', '26363TEGDG22', 'EN2003', 'V8 TX', 'BLUE', 'Headquarters', '2026-10-08', 2, 3, 285, 260, 1, 4, NULL, '2026-10-08 05:34:44', '2026-10-08 05:34:44'),
(32, 'KDM 401A', 'DEMO-CH-0031', 'DEMO-EN-0031', 'Toyota Hilux', 'White', 'Field Vehicle', '2022-01-12', 3, 1, 283, 258, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(33, 'KDM 402B', 'DEMO-CH-0032', 'DEMO-EN-0032', 'Nissan X-Trail', 'Silver', 'Admin Vehicle', '2021-04-25', 2, 1, 284, 259, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(34, 'KDM 403C', 'DEMO-CH-0033', 'DEMO-EN-0033', 'Toyota Corolla', 'Blue', 'Pool Vehicle', '2020-08-19', 1, 1, 285, 260, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(35, 'KDM 404D', 'DEMO-CH-0034', 'DEMO-EN-0034', 'Isuzu D-Max', 'Grey', 'Utility Vehicle', '2023-03-07', 3, 2, 286, 261, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(36, 'KDM 405E', 'DEMO-CH-0035', 'DEMO-EN-0035', 'Toyota Prado', 'Black', 'Official Vehicle', '2021-11-02', 2, 1, 287, 262, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(37, 'KDM 406F', 'DEMO-CH-0036', 'DEMO-EN-0036', 'Honda CRF', 'Red', 'Patrol Bike', '2024-02-16', 4, 1, 288, 263, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(38, 'KDM 407G', 'DEMO-CH-0037', 'DEMO-EN-0037', 'Mitsubishi Canter', 'White', 'Transport Vehicle', '2019-06-14', 3, 3, 283, 258, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(39, 'KDM 408H', 'DEMO-CH-0038', 'DEMO-EN-0038', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2023-09-21', 2, 1, 284, 259, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(40, 'KDM 409J', 'DEMO-CH-0039', 'DEMO-EN-0039', 'Nissan Note', 'Grey', 'Pool Vehicle', '2020-12-11', 1, 2, 285, 260, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(41, 'KDM 410K', 'DEMO-CH-0040', 'DEMO-EN-0040', 'Yamaha XT', 'Blue', 'Patrol Bike', '2022-07-30', 4, 4, 286, 261, 1, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(42, 'KDN 501A', 'DEMO-CH-0041', 'DEMO-EN-0041', 'Toyota Hilux', 'White', 'Field Vehicle', '2022-02-08', 3, 1, 315, 290, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(43, 'KDN 502B', 'DEMO-CH-0042', 'DEMO-EN-0042', 'Toyota Prado', 'Black', 'Official Vehicle', '2021-05-17', 2, 1, 316, 291, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(44, 'KDN 503C', 'DEMO-CH-0043', 'DEMO-EN-0043', 'Nissan X-Trail', 'Silver', 'Admin Vehicle', '2020-09-23', 2, 1, 317, 292, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(45, 'KDN 504D', 'DEMO-CH-0044', 'DEMO-EN-0044', 'Isuzu D-Max', 'Grey', 'Utility Vehicle', '2023-01-14', 3, 2, 318, 293, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(46, 'KDN 505E', 'DEMO-CH-0045', 'DEMO-EN-0045', 'Toyota Corolla', 'Blue', 'Pool Vehicle', '2019-08-06', 1, 1, 319, 294, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(47, 'KDN 506F', 'DEMO-CH-0046', 'DEMO-EN-0046', 'Subaru Forester', 'Green', 'Field Vehicle', '2022-10-28', 2, 1, 320, 295, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(48, 'KDN 507G', 'DEMO-CH-0047', 'DEMO-EN-0047', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2024-03-11', 2, 1, 321, 296, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(49, 'KDN 508H', 'DEMO-CH-0048', 'DEMO-EN-0048', 'Nissan Patrol', 'White', 'Patrol Vehicle', '2021-12-19', 2, 3, 322, 297, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(50, 'KDN 509J', 'DEMO-CH-0049', 'DEMO-EN-0049', 'Honda CRF', 'Red', 'Patrol Bike', '2023-06-22', 4, 1, 323, 298, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(51, 'KDN 510K', 'DEMO-CH-0050', 'DEMO-EN-0050', 'Mitsubishi L200', 'Silver', 'Utility Vehicle', '2020-04-03', 3, 4, 324, 299, 32, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(52, 'KDP 601A', 'DEMO-CH-0051', 'DEMO-EN-0051', 'Toyota Corolla', 'White', 'Pool Vehicle', '2022-01-29', 1, 1, 297, 272, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(53, 'KDP 602B', 'DEMO-CH-0052', 'DEMO-EN-0052', 'Toyota Prado', 'Black', 'Official Vehicle', '2021-06-15', 2, 1, 298, 273, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(54, 'KDP 603C', 'DEMO-CH-0053', 'DEMO-EN-0053', 'Nissan X-Trail', 'Silver', 'Admin Vehicle', '2020-10-07', 2, 1, 299, 274, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(55, 'KDP 604D', 'DEMO-CH-0054', 'DEMO-EN-0054', 'Toyota Hilux', 'Grey', 'Field Vehicle', '2023-02-21', 3, 2, 300, 275, 47, NULL, 4, '2026-10-08 05:52:34', '2026-10-08 06:15:59'),
(56, 'KDP 605E', 'DEMO-CH-0055', 'DEMO-EN-0055', 'Isuzu D-Max', 'White', 'Utility Vehicle', '2022-07-18', 3, 1, 301, 276, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(57, 'KDP 606F', 'DEMO-CH-0056', 'DEMO-EN-0056', 'Subaru Forester', 'Blue', 'Pool Vehicle', '2021-09-12', 2, 1, 302, 277, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(58, 'KDP 607G', 'DEMO-CH-0057', 'DEMO-EN-0057', 'Toyota Land Cruiser', 'White', 'Patrol Vehicle', '2024-01-30', 2, 1, 303, 278, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(59, 'KDP 608H', 'DEMO-CH-0058', 'DEMO-EN-0058', 'Nissan Patrol', 'Black', 'Official Vehicle', '2020-05-26', 2, 3, 304, 279, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(60, 'KDP 609J', 'DEMO-CH-0059', 'DEMO-EN-0059', 'Honda CRF', 'Red', 'Patrol Bike', '2023-11-08', 4, 1, 305, 280, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(61, 'KDP 610K', 'DEMO-CH-0060', 'DEMO-EN-0060', 'Toyota Hiace', 'Silver', 'Transport Vehicle', '2019-03-17', 3, 4, 306, 281, 47, NULL, NULL, '2026-10-08 05:52:34', '2026-10-08 05:52:34'),
(62, 'KBQ', '157FMIi', 'EN2003i', 'Mitsubishi', 'BLUE', 'Headquarters', '2026-10-11', 1, 4, 301, 276, 47, 4, 4, '2026-10-10 21:47:34', '2026-10-11 01:29:06');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_assignments`
--

CREATE TABLE `vehicle_assignments` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `assigned_at` datetime DEFAULT current_timestamp(),
  `released_at` datetime DEFAULT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `status` enum('active','released') DEFAULT 'active',
  `released_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_statuses`
--

CREATE TABLE `vehicle_statuses` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `label` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicle_statuses`
--

INSERT INTO `vehicle_statuses` (`id`, `code`, `label`, `category`, `is_active`) VALUES
(1, 'serviceable', 'Serviceable', 'operational', 1),
(2, 'unserviceable', 'Unserviceable', 'non_operational', 1),
(3, 'leased', 'Leased', 'leased', 1),
(4, 'leased_stored', 'Leased - Stored', 'leased', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_status_history`
--

CREATE TABLE `vehicle_status_history` (
  `id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `old_status_id` int(11) NOT NULL,
  `new_status_id` int(11) NOT NULL,
  `changed_by` int(11) NOT NULL,
  `changed_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counties`
--
ALTER TABLE `counties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `region_id` (`region_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk_drivers_region` (`region_id`),
  ADD KEY `fk_drivers_county` (`county_id`),
  ADD KEY `fk_drivers_subcounty` (`subcounty_id`),
  ADD KEY `fk_drivers_location` (`location_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcounty_id` (`subcounty_id`);

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requisition_id` (`requisition_id`);

--
-- Indexes for table `refuel`
--
ALTER TABLE `refuel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requisition_id` (`requisition_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requisitions`
--
ALTER TABLE `requisitions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `requested_by` (`requested_by`),
  ADD KEY `fk_approved_by` (`approved_by`);

--
-- Indexes for table `subcounties`
--
ALTER TABLE `subcounties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `county_id` (`county_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `username_2` (`username`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `county_id` (`county_id`),
  ADD KEY `subcounty_id` (`subcounty_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `idx_users_region_scope` (`region_id`,`county_id`,`subcounty_id`,`location_id`),
  ADD KEY `idx_users_last_login` (`last_login`),
  ADD KEY `idx_users_last_activity` (`last_activity`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_token` (`session_token`),
  ADD KEY `idx_user_sessions_user_token` (`user_id`,`session_token`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`),
  ADD KEY `idx_vehicles_regno` (`regno`),
  ADD KEY `idx_vehicles_location_id` (`location_id`),
  ADD KEY `idx_vehicles_subcounty_id` (`subcounty_id`),
  ADD KEY `idx_vehicles_county_id` (`county_id`),
  ADD KEY `idx_vehicles_category_id` (`category_id`),
  ADD KEY `idx_vehicles_status_id` (`status_id`),
  ADD KEY `idx_vehicles_created_at` (`created_at`),
  ADD KEY `idx_region_composite` (`county_id`,`subcounty_id`,`location_id`),
  ADD KEY `idx_category_status` (`category_id`,`status_id`);

--
-- Indexes for table `vehicle_assignments`
--
ALTER TABLE `vehicle_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assigned_by` (`assigned_by`),
  ADD KEY `idx_vehicle_active` (`vehicle_id`,`released_at`),
  ADD KEY `idx_driver_active` (`driver_id`,`released_at`),
  ADD KEY `released_by` (`released_by`);

--
-- Indexes for table `vehicle_statuses`
--
ALTER TABLE `vehicle_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_status_history`
--
ALTER TABLE `vehicle_status_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vehicle_id` (`vehicle_id`),
  ADD KEY `old_status_id` (`old_status_id`),
  ADD KEY `new_status_id` (`new_status_id`),
  ADD KEY `changed_by` (`changed_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `counties`
--
ALTER TABLE `counties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2778;

--
-- AUTO_INCREMENT for table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `refuel`
--
ALTER TABLE `refuel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `requisitions`
--
ALTER TABLE `requisitions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subcounties`
--
ALTER TABLE `subcounties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `vehicle_assignments`
--
ALTER TABLE `vehicle_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicle_statuses`
--
ALTER TABLE `vehicle_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vehicle_status_history`
--
ALTER TABLE `vehicle_status_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
